## Introduction ##
 As per the instruction given project is divided into 2 part
	* FrontEnd : Built using Angular
	* BackEnd(API) : Built using .NET Core 3.1

### Instruction for testing ###
	#BackEnd
		* Open folder BackEnd\MontyHall using VisualStudio Code
		* Start debugging in visual studio
		* Swagger will open as defult
		* Test functionality using swagger
	#FrontEnd
		* Open folder FrontEnd\MontyHall using VisualStudio Code
		* Open terminal 
		* execute command npm install -g or npm update (In order to get node_module folder locally)
		* Ruexecute commandn npm install --save-dev @angular-devkit/build-angular (To get missing angular dependency)
		* Run 'ng serve' in order to compile and run front-end
		* browse url http://localhost/home in browser in order to load frontend
		* Start testing end-end

	
