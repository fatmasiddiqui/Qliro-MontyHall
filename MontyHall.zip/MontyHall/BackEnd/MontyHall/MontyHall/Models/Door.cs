﻿namespace MontyHall.Api.Models
{
    public class Door
    {
        public Door(int doorNumber)
        {
            DoorNumber = doorNumber;

        }
        public int DoorNumber { get; set; }
        public bool IsSelected { get; set; }
        public bool IsPrize { get; set; }
        
    }
}
