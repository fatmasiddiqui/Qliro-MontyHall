﻿using System.Text.Json.Serialization;

namespace MontyHall.Api
{
    public class SimulationRequest
    {
        [JsonPropertyName("doorChange")]
        public bool DoorChange { get; set; }
        [JsonPropertyName("noOfSimulations")]
        public int NoOfSimulations { get; set; }

       
    }

    public class SimulationResponse
    {
        [JsonPropertyName("winCount")]
        public int WinCount { get; set; }
        [JsonPropertyName("lossCount")]
        public int LossCount { get; set; }
    }
}
