﻿using MontyHall.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace MontyHall.Api
{
    public interface IMontyHallHandler
    {
        public SimulationResponse StartSimulation(SimulationRequest request);
    }
    public class MontyHallHandler : IMontyHallHandler
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public SimulationResponse StartSimulation(SimulationRequest request)
        {
             var winCount = 0;
            var lossCount = 0;

            for (int i = 0; i < request.NoOfSimulations; i++)
            {
                bool win = StartGame(request.DoorChange);
                if (win)
                    winCount++;
                else lossCount++;
            }

            return new SimulationResponse
            {
                WinCount  = winCount,
                LossCount = lossCount
            };

        }

        private bool StartGame(bool doorChange)
        {
            Random random = new Random();
            int prize = random.Next(0, 3);
            int selection = random.Next(0, 3);

            // available doors for chosing
            var doorOptions = new List<Door> { new Door(1), new Door(2), new Door(3) };
            doorOptions[prize].IsPrize = true;
            doorOptions[selection].IsSelected = true;
            Door selectedDoor = doorOptions[selection];

            // one of the doors that is displayed(goat)
            var displayedDoor = doorOptions.FirstOrDefault(x => !x.IsSelected && !x.IsPrize);
          
            doorOptions.Remove(displayedDoor);

            // door change option
            if (doorChange)
            {
                selectedDoor = doorOptions.FirstOrDefault(x => !x.IsSelected);
                selectedDoor.IsSelected = true;
            }

            return selectedDoor.IsPrize;
        }
    }
    
}

    

