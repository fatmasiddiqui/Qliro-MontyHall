﻿using System;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace MontyHall.Api.Middleware
{
    public class ExceptionalHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        public ExceptionalHandlingMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            _next   = next;
            _logger = loggerFactory.CreateLogger<ExceptionalHandlingMiddleware>(); 
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception e)
            {
                _logger.LogError($"Fatal {e.Message} {e}");

                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                context.Response.ContentType = "application/json";

                await context.Response.WriteAsync(e.Message);
            }
        }
    }
}
