﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace MontyHall.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MontyHallController : ControllerBase
    {
        private readonly IMontyHallHandler _montyHallHandler;

        public MontyHallController(IMontyHallHandler montyHallHandler)
        {
            _montyHallHandler = montyHallHandler;
        }
        // GET: api/MontyHall
        [HttpGet("SimulationCheck")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SimulationResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult SimulationCheck(bool doorChange, int numberOfSimulation)
        {
           
            if (numberOfSimulation <= 0)
                return BadRequest("Number Of Simulations should be greater than zero");

            var request = new SimulationRequest
            {
                DoorChange = doorChange,
                NoOfSimulations = numberOfSimulation
            };

            var response = _montyHallHandler.StartSimulation(request);
            return Ok(response);
        }





        // GET: api/MontyHall/5


        // POST: api/MontyHall


        // PUT: api/MontyHall/5

    }
}
