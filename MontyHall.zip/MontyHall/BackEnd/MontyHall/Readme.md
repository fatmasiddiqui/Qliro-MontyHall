## Introduction ##
 MontyHall.Api Solution is built with .NET Core 3.1
 It contains 2 projects
	*	MontyHall.Api :  ASP.NET Core WebAPI project
	*	MontyHall.Api.Tests : Test projects for unit testing
	
