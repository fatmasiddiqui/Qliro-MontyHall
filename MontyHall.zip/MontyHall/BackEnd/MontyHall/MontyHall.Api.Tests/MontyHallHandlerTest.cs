﻿using AutoFixture.Xunit2;
using Xunit;

namespace MontyHall.Api.Tests
{
    public class MontyHallHandlerTest
    {
        private readonly IMontyHallHandler _sut;

        public MontyHallHandlerTest()
        {
            _sut = new MontyHallHandler();
        }

        [Theory,AutoData]
        public void StartSimulation_when_doorChange_is_true(SimulationRequest simulationRequest)
        {
            simulationRequest.DoorChange = true;
            var result = _sut.StartSimulation(simulationRequest);
            Assert.True(result.WinCount > result.LossCount);
           
        }

        [Theory, AutoData]
        public void StartSimulation_when_doorChange_is_false(SimulationRequest simulationRequest)
        {
            simulationRequest.DoorChange = false;
            var result = _sut.StartSimulation(simulationRequest);
            Assert.True(result.WinCount < result.LossCount);

        }

    }
}
