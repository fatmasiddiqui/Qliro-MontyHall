using Moq;
using MontyHall.Api.Controllers;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using AutoFixture.Xunit2;

namespace MontyHall.Api.Tests
{

    public class MontyHallControllerTest
    {
        private readonly Mock<IMontyHallHandler> _mockMontyHallHandler;
        private readonly MontyHallController _sut;

        public MontyHallControllerTest()
        {

            _mockMontyHallHandler = new Mock<IMontyHallHandler>();
            _sut = new MontyHallController(_mockMontyHallHandler.Object);

        }

        [Theory, AutoData]
        public void SimulationCheck_returns_success(SimulationResponse simulationResponse)
        {
           
            _mockMontyHallHandler.Setup(x => x.StartSimulation(It.IsAny<SimulationRequest>()))
                           .Returns(simulationResponse);

            var result = _sut.SimulationCheck(It.IsAny<bool>(), 100);
            var content = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(StatusCodes.Status200OK, content.StatusCode);
            _mockMontyHallHandler.Verify(x => x.StartSimulation(It.IsAny<SimulationRequest>()), Times.Once);

        }
        [Theory, AutoData]
        public void RunSimulation_returns_badrequest(SimulationResponse simulationResponse)
        {

            _mockMontyHallHandler.Setup(x => x.StartSimulation(It.IsAny<SimulationRequest>()))
                .Returns(simulationResponse);
            var result = _sut.SimulationCheck(It.IsAny<bool>(), 0);
            var content = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(StatusCodes.Status400BadRequest, content.StatusCode);
            _mockMontyHallHandler.Verify(x => x.StartSimulation(It.IsAny<SimulationRequest>()), Times.Never);
        }
    }
}


