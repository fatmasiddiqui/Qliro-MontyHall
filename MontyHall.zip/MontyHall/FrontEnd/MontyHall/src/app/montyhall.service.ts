import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MontyhallService {

  private REST_API_SERVER = "http://localhost:5000/api/MontyHall/SimulationCheck";
  constructor(private httpClient: HttpClient) { }

  public sendGetRequest(doorChange:boolean ,numberOfSimulation:number){

    const url = `${this.REST_API_SERVER}?doorChange=${doorChange}&numberOfSimulation=${numberOfSimulation}`;
    return this.httpClient.get(url);
  }
}
