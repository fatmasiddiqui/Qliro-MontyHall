import { TestBed } from '@angular/core/testing';

import { MontyhallService } from './montyhall.service';

describe('MontyhallService', () => {
  let service: MontyhallService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MontyhallService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
