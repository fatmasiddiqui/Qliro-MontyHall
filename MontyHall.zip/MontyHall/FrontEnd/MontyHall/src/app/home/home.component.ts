import { Component, OnInit } from '@angular/core';
import { MontyhallService } from '../montyhall.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  simulationResponse:any;
  errorMessage:string;
  numberOfSimulation:number;
  doorChange:boolean;
  constructor(private montyHallService: MontyhallService) { }

  ngOnInit(): void {
  
  }

  startSimulation(){
    console.log(this.numberOfSimulation)
    console.log(this.doorChange)
    this.montyHallService.sendGetRequest(this.doorChange,this.numberOfSimulation)
    .subscribe((data: any)=>{
      console.log(data);
      this.simulationResponse=data;
      this.errorMessage=undefined;
    },error => {
      console.log(error);
      this.errorMessage=error.message;
      this.simulationResponse=undefined;
    });
  }

}
